const btnContinuar = document.getElementById('Continuar');
const btnContinuar2 = document.getElementById('Continuar-2');
const btnFinalizar = document.getElementById('Finalizar');
const createPt1 = document.getElementById('create-pt1');
const createPt2 = document.getElementById('create-pt2');
const createFinal = document.getElementById('create-final');
const btnCriar = document.getElementById('Criar');
STG = document.getElementById('forca');
DTS = document.getElementById('destreza');
CON = document.getElementById('constituicao');
INT = document.getElementById('inteligencia');
SBD = document.getElementById('sabedoria');
CRM = document.getElementById('carisma');

const choice = document.getElementsByName('choice');

atributos = [STG, DTS, CON, INT, SBD, CRM];


function criar(){
    createPt1.style.display = 'block';
    btnCriar.style.display = 'none';
}

function continuar(){
    createPt1.style.display = 'none';
    createPt2.style.display = 'flex';
}

function continuar2(){
    createPt2.style.display = 'none';
    createFinal.style.display = 'flex';
}

function finalizar(){
    alert("Personagem criado com sucesso!");
    createFinal.style.display = 'none';
    btnCriar.style.display='block';
}

let currentIndex = 0;

function rollDiceRandom() {
    
    let dado = Math.floor(Math.random() * 20) + 1;
    console.log(dado);

    atributos[currentIndex].value = dado;


    const d20 = document.getElementById('d20');
    d20.value = dado;


    currentIndex++;


    if (currentIndex >= atributos.length) {
        currentIndex = 0;
    }
}

